#!/usr/bin/env bash

echo "📂 Entrando no projeto FRONTEND StopBetPro..."
cd ~/StopBetPro_project

echo "📌 Local atual:"
pwd

echo "📂 Listando arquivos do projeto:"
ls -l
