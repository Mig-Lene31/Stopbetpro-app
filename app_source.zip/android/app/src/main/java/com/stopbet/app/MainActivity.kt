package com.stopbet.app

import com.facebook.react.ReactActivity

class MainActivity : ReactActivity() {
    override fun getMainComponentName(): String? {
        return "StopBetPro" // Nome do app no React Native
    }
}
