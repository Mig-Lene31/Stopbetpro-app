import AppNavigator from './AppNavigator';

export { AppNavigator };
