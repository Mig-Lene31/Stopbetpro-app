import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { createUnlockPayment, confirmPayment } from '../services/payment';

export default function BlockedScreen() {
  const [payment, setPayment] = useState(null);

  const unlockEarly = async () => {
    const p = await createUnlockPayment(50); // desbloqueio por 50 reais
    setPayment(p);
    const confirmed = await confirmPayment(p.id);
    if (confirmed) {
      alert('App desbloqueado!');
      setPayment(null);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>⚠️ BLOQUEADO ⚠️</Text>
      {!payment ? (
        <Button title="Desbloquear agora (R$50)" onPress={unlockEarly} />
      ) : (
        <Text>Processando pagamento...</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  title: { fontSize: 24, marginBottom: 20, textAlign: 'center' }
});
