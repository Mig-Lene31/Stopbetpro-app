#!/data/data/com.termux/files/usr/bin/bash
echo "🔍 Lendo vpn.js..."
sed -n '1,200p' ~/StopBetPro_project/src/services/vpn.js
