export const FEATURES = {
  ACCESSIBILITY_ENABLED: false,
  OCR_ENABLED: false,
  VPN_ENABLED: false,
};
