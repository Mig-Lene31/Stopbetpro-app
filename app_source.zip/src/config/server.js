export const SERVER_CONFIG = {
  BASE_URL: 'http://127.0.0.1:3000',
  TIMEOUT: 8000
};
