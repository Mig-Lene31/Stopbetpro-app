#!/data/data/com.termux/files/usr/bin/bash
echo "🔍 Lendo balanceListener.js..."
sed -n '1,200p' ~/StopBetPro_project/src/services/balanceListener.js
