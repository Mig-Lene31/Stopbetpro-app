import { NativeEventEmitter, NativeModules } from 'react-native';

const { StopAccessibility } = NativeModules;

const emitter = new NativeEventEmitter(StopAccessibility);

let subscription = null;

export function startAccessibilityListener(onBalanceDetected) {
  if (subscription) return;

  subscription = emitter.addListener(
    'StopAccessibilityText',
    (text) => {
      onBalanceDetected(text);
    }
  );
}

export function stopAccessibilityListener() {
  if (subscription) {
    subscription.remove();
    subscription = null;
  }
}
