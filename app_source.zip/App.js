$(cat App.js)
