#!/usr/bin/env bash

echo "📂 Entrando no projeto BACKEND StopBet..."
cd ~/stopbet-backend

echo "📌 Local atual:"
pwd

echo "📂 Listando arquivos do backend:"
ls -l
